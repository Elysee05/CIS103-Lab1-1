#List operations
integers = [1,4,7,8,3]
print(integers)
integers.append(5)
print(integers)
integers.remove(7)
print(integers)
integers.sort(reverse=True)
print(integers)