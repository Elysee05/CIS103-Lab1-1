#for loop string cislab103
s = "CIS103Lab3"
for i in s:
    print(i)