#Tuple Operations
numbers = (4,5,6,7,8)
print(numbers)
print(numbers[0::4])
#changing element 2 in the tuple
#numbers.remove(6)
#print(numbers) - returns the following error because tuples can be immutable
#File
#"C:\Users\17736\PycharmProjects\sample00\Lab 3.py", line
#47, in < module >