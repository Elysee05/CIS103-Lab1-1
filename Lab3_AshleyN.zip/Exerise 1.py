
#while loop  1-10 exits at 7
number = 1
while number <= 10:
    print(number)
    number += 1
    if number >= 8:
        break