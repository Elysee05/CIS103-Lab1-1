#radius program
import math
r = float(input("enter the radius os the sphere: "))
d = 2 * r
c = 2 * math.pi * r
s_a = 4 * math.pi * r**2
v = (4/3) * math.pi * r**3
print("diameter", d)
print("circumference", c)
print("Surface Area", s_a)
print("Volume", v)