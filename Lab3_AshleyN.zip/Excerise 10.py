# CIS 103: Introduction to Programming
# Assignment 03: "Coding practice"
# Instructor: Md Ali
# Date: 09/2/2024
#Coding exercises
#String Reversal  "Lab3Python" using slicing
def reverse_string(string):
    string = string[::-1]
    return string
string = "Lab3Python"
print(reverse_string(string))