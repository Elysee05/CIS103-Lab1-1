#Break and continue exercise 1
number = 1
while number <= 10:
    if number == 5:
        number += 1
        continue
    elif number >= 8:
        break
    print(number)
    number += 1