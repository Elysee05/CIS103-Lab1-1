#Mean program
import statistics
test_list = [4, 5, 8, 9, 10, 17]
print("The original list : " + str(test_list))
res = statistics.median(test_list)
print("Median of list is : " + str(res))