#Dictionary
student_info = {'name':'alice','age':22,'major':"Computer Science"}
print(student_info)
new_key = ('GPA')
new_value =(0)
updated_dict = {**student_info, new_key:new_value}
print(updated_dict)
updated_dict['age'] = 23
print(updated_dict)
del updated_dict['major']
print(updated_dict)