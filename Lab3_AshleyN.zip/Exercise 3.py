#Nest loops creating a pattern
number_of_astericks = 5
def draw(number_of_astericks):
    for i in range(number_of_astericks):
        asterick = ""
        for _ in range(number_of_astericks-i):
            asterick += "*"
        print(asterick)
draw(number_of_astericks)